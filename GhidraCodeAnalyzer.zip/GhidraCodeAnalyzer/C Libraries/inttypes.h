#ifndef _INTTYPES_H
#include <stdlib/inttypes.h>
#ifndef _ISOMAC
libc_hidden_proto (strtoumax)
#endif
#endif
