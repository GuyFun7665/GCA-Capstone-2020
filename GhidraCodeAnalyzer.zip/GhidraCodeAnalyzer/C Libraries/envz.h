#ifndef _ENVZ_H

#include <string/envz.h>

# ifndef _ISOMAC

libc_hidden_proto (envz_entry)
libc_hidden_proto (envz_remove)

# endif /* !_ISOMAC */
#endif
