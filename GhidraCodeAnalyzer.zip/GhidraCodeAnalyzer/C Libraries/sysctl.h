#ifndef _SYS_SYSCTL_H
#include_next <sys/sysctl.h>
#endif  /* _SYS_SYSCTL_H */
