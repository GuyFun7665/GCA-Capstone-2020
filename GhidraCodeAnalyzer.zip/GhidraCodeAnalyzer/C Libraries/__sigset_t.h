#ifndef ____sigset_t_defined
#define ____sigset_t_defined 1

/* A `sigset_t' has a bit for each signal.  */
typedef unsigned long int __sigset_t;

#endif
