#ifndef _RPC_PMAP_PROT_H
#include <sunrpc/rpc/pmap_prot.h>

# ifndef _ISOMAC

libc_hidden_proto (xdr_pmap)
libc_hidden_proto (xdr_pmaplist)

# endif /* !_ISOMAC */
#endif /* rpc/pmap_prot.h */
