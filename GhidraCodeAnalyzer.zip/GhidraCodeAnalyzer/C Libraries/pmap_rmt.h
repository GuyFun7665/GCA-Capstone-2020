#ifndef _RPC_PMAP_RMT_H
#include <sunrpc/rpc/pmap_rmt.h>

# ifndef _ISOMAC

libc_hidden_proto (xdr_rmtcall_args)
libc_hidden_proto (xdr_rmtcallres)

# endif /* !_ISOMAC */
#endif /* rpc/pmap_rmt.h */
