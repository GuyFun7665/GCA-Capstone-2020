#include <stdlib/bits/monetary-ldbl.h>
