#include <resolv/bits/types/res_state.h>
